/**
 * @author Shubham Sharma & Carter Ronald
 */
public class Endpoint {

    private int value;

    public Endpoint(int value) {
       this.value = value;
    }

    public int getValue(){
        return  value;
    }
}
